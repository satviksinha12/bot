
const { InteractionType, InteractionResponseType, verifyKey } = require('discord-interactions');
const admin = require('firebase-admin');

/**
 * Bulletproof IBM Code Engine Function
 */
async function main(params) {
    console.log("=== INVOCATION START ===");

    try {
        // 1. Basic Health Check
        const headers = params.__ow_headers || {};
        const signature = headers['x-signature-ed25519'] || headers['X-Signature-Ed25519'];
        const timestamp = headers['x-signature-timestamp'] || headers['X-Signature-Timestamp'];

        if (!signature || !timestamp) {
            console.log("Health check: Returning 200 OK");
            return {
                statusCode: 200,
                headers: { 'Content-Type': 'text/plain; charset=utf-8' },
                body: "✈️ Virtual Skies Bot is ONLINE.\nReady for Discord Webhooks at this URL."
            };
        }

        // 2. Validate Environment
        const PUBLIC_KEY = params.DISCORD_PUBLIC_KEY;
        if (!PUBLIC_KEY) {
            console.error("Missing DISCORD_PUBLIC_KEY");
            return { statusCode: 500, body: "Error: Missing configuration (Public Key)" };
        }

        // 3. Body Verification
        let rawBody = params.__ow_body;
        if (params.__ow_decode && typeof rawBody === 'string') {
            rawBody = Buffer.from(rawBody, 'base64');
        } else if (typeof rawBody === 'string') {
            rawBody = Buffer.from(rawBody, 'utf-8');
        } else if (rawBody && typeof rawBody === 'object') {
            rawBody = Buffer.from(JSON.stringify(rawBody), 'utf-8');
        }

        if (!verifyKey(rawBody, signature, timestamp, PUBLIC_KEY)) {
            console.error("Signature verification failed.");
            return { statusCode: 401, body: "Invalid signature" };
        }

        const interaction = JSON.parse(rawBody.toString('utf-8'));

        // 4. Handle PING
        if (interaction.type === InteractionType.PING) {
            return {
                statusCode: 200,
                headers: { 'Content-Type': 'application/json' },
                body: { type: InteractionResponseType.PONG }
            };
        }

        // 5. Firebase Setup
        if (!admin.apps.length) {
            admin.initializeApp({
                credential: admin.credential.cert({
                    projectId: params.FIREBASE_PROJECT_ID,
                    clientEmail: params.FIREBASE_CLIENT_EMAIL,
                    privateKey: params.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n'),
                }),
                databaseURL: params.FIREBASE_DATABASE_URL
            });
        }

        // 6. Command Handling
        if (interaction.type === InteractionType.APPLICATION_COMMAND) {
            const { name } = interaction.data;
            const db = admin.firestore();
            const rtdb = admin.database();

            if (name === 'ping') {
                return {
                    statusCode: 200,
                    headers: { 'Content-Type': 'application/json' },
                    body: { type: InteractionResponseType.CHANNEL_MESSAGE_WITH_SOURCE, data: { content: "Pong! ✈️ IBM is active." } }
                };
            }

            if (name === 'who') {
                const data = (await rtdb.ref('live_flights').once('value')).val();
                let content = "No pilots flying. 🛫";
                if (data) {
                    const active = Object.values(data).filter(f => Date.now() - f.lastContact < 600000);
                    if (active.length) {
                        content = active.map(f => `**${f.callsign}**: ${f.dep}➔${f.arr}`).join('\n');
                    }
                }
                return {
                    statusCode: 200,
                    headers: { 'Content-Type': 'application/json' },
                    body: { type: InteractionResponseType.CHANNEL_MESSAGE_WITH_SOURCE, data: { content } }
                };
            }

            // Default response for other commands
            return {
                statusCode: 200,
                headers: { 'Content-Type': 'application/json' },
                body: { type: InteractionResponseType.CHANNEL_MESSAGE_WITH_SOURCE, data: { content: "Command received." } }
            };
        }

        return { statusCode: 400, body: "Unhandled request" };

    } catch (err) {
        console.error("Fatal Error:", err.message);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ error: err.message })
        };
    }
}

module.exports.main = main;
